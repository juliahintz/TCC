<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
		<script type="text/javascript" src="funcoes.js"></script>
  		<link rel="stylesheet" type="text/css" href="estilo.css">
  		<link rel="stylesheet" type="text/css" href="css.css">
   		<script type="text/javascript" src="semantic/semantic.min.js"></script>
  		<script type="text/javascript" src="funcoes.js"></script>
  		<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
		<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
		<link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
<?php
  	include('cabecalho.php');
?>
	</head>
	<body>
   	 <div id="carouselFade" class="carousel slide carousel-fade" data-ride="carousel">
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">  
                <div class="carousel-caption">
                  <h3>KNOW THE GAME</h3>
                  <p>Conhecer é fundamental para ensinar!</p>
                  <h5>RESENHAS DE JOGOS INFANTIS</h5>
                </div>
            </div>
            <div class="item" style="background-image:('imagens/principal.jpg')"> 
                <div class="carousel-caption">
                  <h3>CASTLE OF ILLUSION</h3>
                  <p>Jogo muito popular entre as crianças, conheça-o agora</p>
                </div>
            </div>
            <div class="item"> 
                <div class="carousel-caption">
                  <h3>MEU MALVADO FAVORITO: MINIONS RUSH</h3>
                  <p>Em breve resenha dos queridinhos</p>
                </div>
            </div>
            <div class="divider">.</div>
            <div class="divider">.</div>
            <section class="sides2">!</section>
		<section id="total" class="comentarios">
			<h3 class="ui horizontal divider header" id="corcadastrar">
       			 <i class="list icon"></i>
       			RESENHAS DISPONÍVEIS
      		</h3>
		</section>
		<section class="sides2">!</section>
        </div>

        

        <!-- Controls -->
        <a class="left carousel-control" href="#carouselFade" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carouselFade" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

	<section class="sides">.</section>
	<section id="jogos">
		<br>
	<section class="texto">	
		<div class="zoom">
			<a href="resenhaduck.php"><img class="medium ui image texto" class="img-responsive" src="imagens/ducktales.jpg.png"></a>
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>Ducktales (RESMASTERED)<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
   		<p class="corparag">.</p>
    	<section class="fontetexto">Tio Patinhas viaja pelo mundo coletando tesouros e com o objetivo de ser o mais rico do planeta. Além dele, seus sobrinhos, Huguinho, Zezinho e Luizinho são outros que participam das aventuras e têm que enfrentar cenários bem desafiadores, de muitos obstáculos e também recompensas. DuckTales: Remastered é uma bela reimaginação feita a mão de um dos mais queridos títulos de 8-bits de todos os tempos. Volte a uma das eras de ouro dos videogames, mas agora refinada com um nível de detalhe que vai agradar o mais exigente fã da Disney ou da Capcom retrô. [...]

   		<div class="divider">.</div>
   		<p><a href="resenhaduck.php"><u>LEIA A RESENHA</u></a></p>
    	<div class="divider">.</div>

   		<section class="ficadireita">
			<img src="imagens/dez.png" class="tamanhofaxa">
		
    		<div class="ui labeled button" tabindex="0">
  				<div class="ui red button">
   					 <i class="heart icon"></i> Gostaram
  				</div>
  				<a class="ui basic red left pointing label">764</a>
			</div> 	
    	</section>
		</section>

	</section>

	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<div class="zoom">
			<a href="resenhadisney.php"><img class="medium ui image texto" class="img-responsive" src="imagens/disney.png"></a>
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>Disney Infinity 2.0<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
   		<p class="corparag">.</p>
		<section class="fontetexto">Disney Infinity 2.0 é o novo jogo para Xbox One, Xbox 360, PlayStation 3 e 4, Wii U e PS Vita da franquia que usa bonecos reais para controlar personagens no game dentro das telas. Contando com personagens carismáticos como do mundo Marvel como Homem de Ferro, Hulk, Thor e outros como Alladdin, o game traz a possibilidade de encarnar os heróis da Marvel que estão na moda. [...]

			<div class="divider">.</div>
    		<p><a href="resenhadisney.php"><u>LEIA A RESENHA</u></a></p>
    		<div class="divider">.</div>

    		<section class="ficadireita">
				<img src="imagens/dez.png" class="tamanhofaxa">
		
    			<div class="ui labeled button" tabindex="0">
  					<div class="ui red button">
    				<i class="heart icon"></i> Gostaram</div>
  					<a class="ui basic red left pointing label">138</a>
				</div> 	
    		</section>
		</section>
	</section>

	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<div class="zoom">
			<a href="resenhacave.php"><img class="medium ui image texto" class="img-responsive" src="imagens/cave.jpg.png"></a>
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>The Cave<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
    	<p class="corparag">.</p>
    	<section class="fontetexto">A caverna é um local misterioso, que explora os maiores medos e esperanças de todos os aventureiros que passam por ela. O game reúne um grupo com características distintas, mas com a ambição de conquistar seus objetivos não importa o tamanho dos desafios. Descendo pelas paredes úmidas, os jogadores poderão encontrar cenários como um centro de pesquisa, um parque de diversão e até um ambiente inspirado no antigo Egito. [...]

			<div class="divider">.</div>
			<p><a href="resenhacave.php"><u>LEIA A RESENHA</u></a></p>
			 <div class="divider">.</div>

  			<section class="ficadireita">
			<img src="imagens/catorze.png" class="tamanhofaxa">
		
    		<div class="ui labeled button" tabindex="0">
  				<div class="ui red button">
    				<i class="heart icon"></i> Gostaram
  				</div>
  				<a class="ui basic red left pointing label">547</a>
			</div> 	
  		  </section>
		</section>
	</section>

	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<a href="resenhacastle.php">
		<div class="zoom">
			<a href="resenhacastle.php"><img class="medium ui image texto" class="img-responsive" src="imagens/castle.jpg.png"></a>
		</div>
		</a>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>Castle of Illusion<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
   	 	<p class="corparag">.</p>
    	<section class="fontetexto">Os pombinhos Mickey e Minnie estavam curtindo um dia feliz de verão, até que uma tempestade se aproximou inesperadamente. A malvada bruxa Mizrabel estava por trás de tudo para sequestrar Minnie e, por inveja de sua beleza, roubar sua juventude. Mickey tem então de salvar sua amada, seguindo a vilã até seu castelo e atravessando as armadilhas de ilusão. [...]

			<div class="divider">.</div>
    		<p><a href="resenhacastle.php"><u>LEIA A RESENHA</u></a></p>
    		<div class="divider">.</div>

   			 <section class="ficadireita">
					<img src="imagens/dez.png" class="tamanhofaxa">
   					<div class="ui labeled button" tabindex="0">
  						<div class="ui red button">
   							<i class="heart icon"></i> Gostaram
  						</div>
  						<a class="ui basic red left pointing label">491</a>
					</div> 	
    		</section>
		</section>
	</section>
	
	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<div class="zoom">
		<a href="resenhaterraria.php"><img class="medium ui image texto" class="img-responsive" src="imagens/terraria.png"></a>
	</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>Terraria<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
   		<p class="corparag">.</p>
   		<section class="fontetexto">Terraria é um game 2D baseado em Minecraft onde você escolhe seu personagem e viaja para um mundo gerado aleatoriamente repleto de blocos que podem ser destruídos e colocados em qualquer lugar. Terraria é uma terra de aventura! Uma terra de mistérios! Uma terra que é toda sua para modelar, defender, e se divertir. Suas opções em terraria são infinitas. Você é um jogador com o dedo no gatilho? Um grande construtor? Um colecionador? Um aventureiro? Aqui tem algo para todos. [...]

			<div class="divider">.</div>
    		<p><a href="resenhaterraria.php"><u>LEIA A RESENHA</u></a></p>
   			<div class="divider">.</div>

   			<section class="ficadireita">
				<img src="imagens/livre.png" class="tamanhofaxa">
		
    			<div class="ui labeled button" tabindex="0">
  					<div class="ui red button">
   						<i class="heart icon"></i> Gostaram
  					</div>
  					<a class="ui basic red left pointing label">851</a>
				</div> 	
   			</section>
		</section>
	</section>
	
	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<div class="zoom">
			<a href="resenhanaruto.php"><img class="medium ui image texto" class="img-responsive" src="imagens/naruto.png"></a> 
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>Naruto<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
    	<p class="corparag">.</p>
    	<section class="fontetexto">Ultimate Ninja Storm 4 retoma a história em que o jogo anterior terminou. As Forças Aliadas Shinobi têm a vantagem sobre a Akatsuki, mas Tobi e Madara Uchiha continuam sendo obstáculos constantes para os heróis. Naruto, então, deve se unir aos aliados para tentar derrotar a dupla e impedir que completem o plano de conquista mundial. [...]

			<div class="divider">.</div>
			<p><a href="resenhanaruto.php"><u>LEIA A RESENHA</u></a></p>
			<div class="divider">.</div>

   			<section class="ficadireita">
				<img src="imagens/catorze.png" class="tamanhofaxa">
		
 				<div class="ui labeled button" tabindex="0">
  					<div class="ui red button">
   					<i class="heart icon"></i> Gostaram
  					</div>
  					<a class="ui basic red left pointing label">1265</a>
				</div> 	
   	 		</section>
		</section>
	</section>
	
	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<div class="zoom">
			<a href="resenhapes.php"><img class="medium ui image texto" class="img-responsive" src="imagens/pes.jpg"></a> 
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>PES 2015<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
    	<p class="corparag">.</p>
    	<section class="fontetexto">PES 2015 é o novo capítulo da popular franquia de futebol da Konami. Fazendo sua estreia nos consoles da nova geração, PS4 e Xbox One. O jogo marca a volta da essência PES, com o controle total do jogo, resposta imediata dos controles, jogabilidade única, onde os jogadores têm controle completo sobre o jogo e sobre como eles jogam. Cada passe, chute ou corrida estão bem equilibrados para dar ao jogador a melhor experiência. [...]

			<div class="divider">.</div>
   			<p><a href="resenhapes.php"><u>LEIA A RESENHA</u></a></p>
    		<div class="divider">.</div>

   			<section class="ficadireita">
				<img src="imagens/dez.png" class="tamanhofaxa">
		
    			<div class="ui labeled button" tabindex="0">
  					<div class="ui red button">
    				<i class="heart icon"></i> Gostaram</div>
  					<a class="ui basic red left pointing label">932</a>
				</div> 	
  		  	</section>
		</section>
	</section>

	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<div class="zoom">
			<a href="resenharayman.php"><img class="medium ui image texto" class="img-responsive" src="imagens/rayman.jpg.png"></a>
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>Rayman Legends<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
    	<p class="corparag">.</p>
   		<section class="fontetexto">A Clareira dos Sonhos está novamente em apuros! Durante um sono de 100 anos, os pesadelos multiplicaram-se e espalharam-se, criando novos monstros ainda mais aterradores do que antes! Estas criaturas alimentam lendas… Dragões, sapos gigantes, monstros marinhos e até luchadores perversos. Com a ajuda de Murfy, Rayman e Globox acordam e têm agora de ajudar a combater estes pesadelos e a salvar os Teensies! [...]

			<div class="divider">.</div>
   			<p><a href="resenharayman.php"><u>LEIA A RESENHA</u></a></p>
			<div class="divider">.</div>


   			 <section class="ficadireita">
				<img src="imagens/livre.png" class="tamanhofaxa">
		
    			<div class="ui labeled button" tabindex="0">
  					<div class="ui red button">
    					<i class="heart icon"></i> Gostaram
  					</div>
  					<a class="ui basic red left pointing label">127</a>
				</div> 	
    		</section>
		</section>
	</section>

	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">	
		<div class="zoom">
			<a href="resenhakinect.php"><img class="medium ui image texto" class="img-responsive" src="imagens/kinect.png"></a> 
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>Kinect Sports Rivals<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
   		<p class="corparag">.</p>
    	<section class="fontetexto"> Existe um competidor em cada um de nós aguardando ser despertado. O Kinect Sports Rivals traz as competições esportivas para um novo mundo, onde as questões de habilidade e precisão são recompensadas. Teste suas habilidades no futebol, escalada, corrida de jet ski, tiro ao alvo, tênis e boliche. Com Kinect Sports Rivals, é você contra o mundo.
     	Um Mundo de Competição: Escolha os seus poderes, aprimore sua habilidade e aperfeiçoe a sua estratégia para competir em vários esportes, eventos esportivos e torneios on-line. [...]

   		 	<div class="divider">.</div>
			<p><a href="resenhakinect.php"><u>LEIA A RESENHA</u></a></p>
			<div class="divider">.</div>

    		<section class="ficadireita">
				<img src="imagens/catorze.png" class="tamanhofaxa">
				<div class="ui labeled button" tabindex="0">
  					<div class="ui red button">
   						<i class="heart icon"></i> Gostaram
  					</div>
  					<a class="ui basic red left pointing label">426</a>
				</div> 	
    		</section>
     	</section>
 	</section>
	
	<div class="divider">.</div>
	<div class="ui divider"></div>
	<div class="divider">.</div>

	<section class="texto">
		<div class="zoom">
			<a href="resenhafifa.php"><img class="medium ui image texto" class="img-responsive" src="imagens/fifa.png"></a> 
		</div>
	</section>			

	<section class="textor">
		<p class="estrela"><strong>FIFA 2014<section class="corespaco">..</section></strong><div class="ui large star rating estrela"></div><p>
   		<p class="corparag">.</p>
		<section class="fontetexto">No 'FIFA 14' da nova geração, você verá detalhes gráficos nos jogadores que nunca foram possíveis antes! Será possível perceber o movimento dos cabelos, a respiração e as reações do rosto. Os uniformes também são realistas e mudam de acordo com o ambiente - ficam sujos de barro e grama conforme o jogo avança. Os jogadores agora têm memória e reagem naturalmente aos principais momentos da partida. [...]

   			<div class="divider">.</div>
    		<p><a href="resenhafifa.php"><u>LEIA A RESENHA</u></a></p>
   			 <div class="divider">.</div>

    		<section class="ficadireita">
				<img src="imagens/dez.png" class="tamanhofaxa">
		
    			<div class="ui labeled button" tabindex="0">
  					<div class="ui red button">
    					<i class="heart icon"></i> Gostaram
  					</div>
  					<a class="ui basic red left pointing label">944</a>
				</div> 	
    	</section>
    </section>
	
	</section>
	
	<div class="divider">.</div>
	<div class="ui divider"></div>	
	<div class="divider">.</div>

	</section>
	</section>
	<section class="sides">.</section>

	<script>
		$('.ui.rating')
 	 .rating({
  	  initialRating: 3,
  	  maxRating: 5
 	 })
	;
	</script>
</html>