      <!DOCTYPE html>
      <html>
      <head>
        <link rel="shortcut icon" href="imagens/favicon.ico" />
        <title>Know The Game (KTG) - Resenhas de Jogos Infantis</title>
        </html>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
        <script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
        <script type="text/javascript" src="semantic/semantic.min.js"></script>
        <script type="text/javascript" src="funcoes.js"></script>
        <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
        <link rel="stylesheet" type="text/css" href="css.css">
        <script>
          menu = {};

      // ready event
      menu.ready = function() {

      // selector cache
      var
      $menuItem = $('.menu a.item, .menu .link.item'),
      // alias
      handler = {
        activate: function() {
          $(this)
          .addClass('active')
          .closest('.ui.menu')
          .find('.item')
          .not($(this))
          .removeClass('active');
        }
      }
      ;
      $menuItem
      .on('click', handler.activate)
      ;

    };
      // attach ready event
      $(document).ready(menu.ready);

    </script>
  </head>
  <div class="ui inverted segment">
   <div class="ui inverted secondary pointing menu">
     <img src="imagens/logo.png" class="logo">
     <div class="dividermenu">...........</div>
     <a href="index.php" style="color: pink" class="active item" class="grafia">
       HOME
     </a>
     <a class="item" class="grafia">
      RESENHAS
    </a>
    <a class="item" style="color: blue" class="grafia">
      AUTORES
    </a>
    <a class="item" class="grafia">
      CONTATO
    </a>
   <a href="cadastro_usuario.php" class="adcmenu">
     CADASTRE-SE | 
   </a>
   <a href="login.php" class="adcmenuu">
     <div class="esconde">..</div>LOGIN
   </a>

   <!-- Caixa de pesquisa -->
   <form action='/search' id='search' method='get' name='searchForm' style='display:inline;'>
    <input id='search-box' name='q' onblur='if (this.value == &quot;&quot;) this.value = &quot;Pesquisar...&quot;;' onfocus='if (this.value == &quot;Pesquisar...&quot;) this.value = &quot;&quot;;' size='28' type='text' value='Pesquisar...'/></form>
  </div>
  </div>
