<!DOCTYPE html>
<html>

<head>
<link rel="shortcut icon" href="imagens/favicon.ico" />
<title>Know The Game (KTG) - Resenhas de Jogos Infantis</title>

<meta charset="utf-8">
<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="semantic/semantic.min.js"></script>
<script type="text/javascript" src="funcoes.js"></script>
<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
<link rel="stylesheet" type="text/css" href="css.css">

</head>
<body class="body2">
<div class="dividerc">.</div>
<div class="dividerc">.</div>

<div class="margem">
<center><img src="imagens/logo.png" class="imglogin"></center>
</div>

<section class="sides3">.</section>

<section class="total3">

<div class="ten wide column">
<center><h4 class="ui header">
	<i class="sign in alternate icon"></i>
	LOGIN DE USUÁRIO
</h4></center>

		<div class="ui form ">
				 <div class="field">
				<label>E-mail</label>
				<input type="email" placeholder="Digite seu e-mail...">
				<i class="user icon"></i>
				 </div>
				 
				 <div class="field">
				<label>Senha</label>
				<input type="password" placeholder="Digite sua senha...">
				 </div>

			<div class="ui form">

					<div class="inline field">
					<div class="ui checkbox" class="direita">
  						<input type="checkbox" tabindex="0" class="hidden">
					 		<label>Mantenha-me conectado</label>
					</div>

					<strong><h5 class="esquerda"><a href="recuperarsenha.php" class="corsenha">Esqueceu sua senha?</a></h5></strong>
					</div>
				<button class="fluid blue ui button">
					<a href="minhasresenhas.php" class="branco">ENTRAR</a>
				</button>

		</div>
		<div class="divider">.</div>
		<div class="divider">.</div>

		<a href="index.php">
			<h5 class="ui header">
				<i class="reply icon"></i>
						VOLTAR
			</h5>
		</a>

	</div>
</section>

<section class="sides3">.</section>
</body>
</html>
<script>
$('.ui.checkbox')
.checkbox()
;
</script>