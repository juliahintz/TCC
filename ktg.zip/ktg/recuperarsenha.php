<!DOCTYPE html>
<html>

	<head>
  <link rel="shortcut icon" href="imagens/favicon.ico" />
  <title>Know The Game (KTG) - Resenhas de Jogos Infantis</title>

  <meta charset="utf-8">
  <script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  <script type="text/javascript" src="semantic/semantic.min.js"></script>
  <script type="text/javascript" src="funcoes.js"></script>
  <link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="css.css">

</head>
<body class="body2">
	<div class="dividerc">.</div>

	<div class="margem">
		<center><img src="imagens/logo.png" class="imglogin"></center>
	</div>

	<section class="sides4">.</section>

	<section class="total4" id="tam">
		<div class="ten wide column">
		<center><h2 class="ui header">
			RECUPERAÇÃO DA SENHA
		</h2></center>
		</div>
		
		<section class="fotoEmail">
		<section class="espacoemail">.</section>
		<img src="imagens/icon.png" class="iconezinho">
		<p class="emaildousuario">emaildousuario@exemplo.com</p>
		</section>

		<div class="divider">.</div>
		<div class="divider">.</div>

		<div class="cartinha">
		<img src="imagens/carta.png" class="carta">
		<section class="escrituras">
		<h4 class="validacao">CÓDIGO DE VALIDAÇÃO</h4>
		<p class="mensagememail">Enviaremos um código de validação da conta, para o seu email secundário:</p>
		<h5 class="segundoemail">emailsecundario@exemplo.com</h5>
		</section>
		</div>

		<div class="divider">.</div>
		<div class="divider">.</div>
		<div class="divider">.</div>
		
        <section class="finalzinho">
        <p class="outraforma">APRESENTAR OUTRA FORMA</p>
		<input type="submit" class="ui blue button" id="enviar3" value="ENVIAR">
		</section>

		<div class="divider">.</div>

		<a href="login.php">
			<h5 class="ui header">
				<i class="reply icon"></i>
						VOLTAR
			</h5>
		</a>