<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

	<div class="divider">.</div>
			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

      <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: THE CAVE</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">A caverna é um local misterioso, que explora os maiores medos e esperanças de todos os aventureiros que passam por ela. O game reúne um grupo com características distintas, mas com a ambição de conquistar seus objetivos não importa o tamanho dos desafios. Descendo pelas paredes úmidas, os jogadores poderão encontrar cenários como um centro de pesquisa, um parque de diversão e até um ambiente inspirado no antigo Egito.</p>
  			
  			<section class="video">	
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/zzixb3N16HU" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
       O jogo conta com a narração da “caverna”: pessoas que vão à sua procura para fifa 14 encontrar o que mais desejam. Alguns encontram o que procuram e outros até chegam a sobreviver, porém, o importante é que a própria caverna tem um história interessante a lhe contar, história a qual é desenvolvida durante o jogo. Suas narrações são sempre sarcásticas e muito engraçadas, tornando-a não apenas sua guia durante o jogo, mas sim a protagonista.
</p>
  			<p class="fontetexto">Após uma breve apresentação, é necessário escolher três entre sete personagens para entrar na caverna, eles são: o monge que busca o equilíbrio, a aventureira que procura por artefatos antigos, o caipira que procura seu verdadeiro amor, a ambiciosa cientista em busca de uma nova descoberta, os travessos irmãos gêmeos que gostam de brincar, o desconhecido guerreiro que procura por uma espada e a viajante do tempo que quer consertar um erro cometido no passado. Cada personagem possui uma habilidade especial que será essencial durante a aventura.

</p>
   			<p class="fontetexto">A história dos personagens acontecem em um cenário de aventura e estratégia, forçando o jogador a explorar, pensar na forma de resolver o problema e a conhecer melhor cada personagem . Assim que uma aventura é iniciada, é necessário terminar a história dos três personagens para que se possa iniciar uma outra. Ou, simplesmente iniciar uma nova, com o preço de perder todo o progresso que teve até então.

</p>
        
       <section class="estrelacomentario">
        <h4>Classificação</h4>
       <div class="ui large star rating estrela estrelacomentari"></div>
   		</section>
      <section class="autorresenha">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Ana Carvalho
        </a>
      </section>
      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/cave2.jpg" class="fotop">
  				<img src="imagens/cave4.jpg" class="fotop">
  				<img src="imagens/cave3.jpg" class="fotop">
  				<img src="imagens/cave4.jpg" class="fotop">
  				<img src="imagens/cave2.jpg" class="fotop">
          
			</div></center>
		</section>
      <div class="divider">.</div>

   <section class="sides2">!</section>

<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

 <div class="margenzinha"></div>
<section id="total">
      <div class="ui comments">
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div class="content">
      <a class="author">Cristina Moraes</a>
      <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>
      <div class="text">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
        <i class="trash icon"></i><a class="delete" >Excluir comentário</a>
      </div>
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
      <a class="author">Samuel Henrique</a>
      <div class="metadata">
        <div class="date">2 dias atrás</div>
      </div>
      <div class="text">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
        <i class="trash icon"></i><a class="delete" >Excluir comentário</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <div class="ui primary submit labeled icon button">
      <i class="icon edit"></i> Comentar
    </div>
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  </script>
</body>
</html>