<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

	<div class="divider">.</div>
			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

      <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: NARUTO SHIPPUDEN - ULTIMATE NINJA STORM 3</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">Ultimate Ninja Storm 4 retoma a história em que o jogo anterior terminou. As Forças Aliadas Shinobi têm a vantagem sobre a Akatsuki, mas Tobi e Madara Uchiha continuam sendo obstáculos constantes para os heróis. Naruto, então, deve se unir aos aliados para tentar derrotar a dupla e impedir que completem o plano de conquista mundial.</p>
  			
  			<section class="video">	
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/p8afUMIMmvM" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
     Naruto Shippuden Ultimate Ninja Storm 3" é uma transformação completa do anime e mangá em videogame, além de se ambientar diretamente após os acontecimentos de seu antecessor "Storm 2. O ponto mais forte de Naruto Shippuden: Ultimate Ninja Storm 3 são os seus visuais coloridos e fiéis ao desenho da TV. Houve claramente uma preferência pela estética sobre a jogabilidade na hora de produzir o título. Com animações sensacionais e personagens muito bem reproduzidos nenhum fã ficará desapontado.

</p>
  			<p class="fontetexto">Mesmo as cutscenes, apesar de longas, são sempre bonitas, possuem boa dublagem e mostram o esforço dos desenvolvedores em fazer o jogo visualmente ideal de Naruto. Mesmo durante as batalhas o título não perde sua beleza, e certamente você corre o risco de acabar morrendo porque passou tempo demais achando o golpe especial do inimigo era tão bacana.


</p>
   			<p class="fontetexto">Apesar do belo visual, Naruto Shippuden: Ultimate Ninja Storm 3 é um jogo cujo apelo fica completamente restrito aos fãs da série. Animações muito longas, a falta de interatividade e jogabilidade simplista e repetitiva acabam tornando o jogo praticamente insuportável para aqueles não familiarizados com a história de Naruto.
</p>
        
       <section class="estrelacomentario">
        <h4>Classificação</h4>
       <div class="ui large star rating estrela estrelacomentari"></div>
   		</section>
      <section class="autorresenha">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Simone Bittencourt
        </a>
      </section>
      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/naruto1.jpg" class="fotop">
  				<img src="imagens/naruto2.jpg" class="fotop">
  				<img src="imagens/naruto3.jpg" class="fotop">
  				<img src="imagens/naruto4.jpg" class="fotop">
  				<img src="imagens/naruto2.jpg" class="fotop">
          
			</div></center>
		</section>
      <div class="divider">.</div>

   <section class="sides2">!</section>

<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

 <div class="margenzinha"></div>
<section id="total">
      <div class="ui comments">
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div class="content">
      <a class="author">Cristina Moraes</a>
      <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>
      <div class="text">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
        <i class="trash icon"></i><a class="delete" >Excluir comentário</a>
      </div>
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
      <a class="author">Samuel Henrique</a>
      <div class="metadata">
        <div class="date">2 dias atrás</div>
      </div>
      <div class="text">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
        <i class="trash icon"></i><a class="delete" >Excluir comentário</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <div class="ui primary submit labeled icon button">
      <i class="icon edit"></i> Comentar
    </div>
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  </script>
</body>
</html>