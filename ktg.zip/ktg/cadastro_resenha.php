<?php  
 include ('menu_dropdown.php');
?>
<body>
   <section class="divider">...</section>
  	<section class="divider">...</section>
     <section class="sides2">!</section>
		<section id="total" class="comentarios">
			<h3 class="ui horizontal divider header" id="corcadastrar">
  			<i class="edit icon" class= "coricone"></i>
 			 CADASTRAR RESENHA
			</h3>
		</section>
		<section class="sides2">!</section>
 
   <section class="divider">...</section>
   <section class="divider">...</section>

   <form method="post" action="" enctype="multipart/form-data" class="ui form" class="centralizando">
    	<section class="cadastraar">
  <div class="field">
  	<div class="field" id="field1">
    <label><h4>TÍTULO DA RESENHA</h4></label>
    <input type="text" name="first-name" id='flutuação' placeholder="Insira nome da resenha...">
  </div>

  <section class="divider">...</section>

  <div class="field" id="field2">
    <label><h4>SINOPSE</h4></label>
    <textarea rows="3" placeholder="Insira a sinopse da resenha..."></textarea>
  </div>

  <section class="divider">...</section>
<div class="field" id="field1">
   <label><h4>FOTO DA CAPA DA RESENHA</h4></label>
    <input type="file" name="arquivo">
  </form>
  </div>

  <section class="divider">...</section>
   <label><strong><h4>RESENHA</h4></strong></label>
   <div class="ui form">
  <div class="field" id="field2">
    <textarea rows="10" placeholder="Insira o texto da resenha..."></textarea>
  </div>
  
<div class="field" id="field4">
	<section class="divider">...</section>
    <label><h4>AUTOR</h4></label>
<div class="ui fluid selection dropdown" id="field2">
  <input type="hidden" name="user">
  <i class="dropdown icon"></i>
  <div class="default text">Selecionar autor...</div>
  <div class="menu">
    <div class="item" data-value="jenny">
      <img class="ui mini avatar image" src="imagens/avatar2.png">
      Jenny Hess
    </div>
    <div class="item" data-value="elliot">
      <img class="ui mini avatar image" src="imagens/avatar1.png">
      Elliot Fu
    </div>
    <div class="item" data-value="stevie">
      <img class="ui mini avatar image" src="imagens/avatar1.png">
      Stevie Feliciano
    </div>
    <div class="item" data-value="christian">
      <img class="ui mini avatar image" src="imagens/avatar2.png">
      Christian
    </div>
    <div class="item" data-value="matt">
      <img class="ui mini avatar image" src="imagens/avatar1.png">
      Matt
    </div>
    <div class="item" data-value="justen">
      <img class="ui mini avatar image" src="imagens/avatar2.png">
      Justen Kitsune
    </div>
  </div>
</div>

<section class="divider">...</section>
<section class="divider">...</section>
   
  <section>

  	<input type="submit" class="positive ui button finaal" id="victopp" value="CADASTRAR">
  	<div class="ui slider checkbox" id="victop">
  <input type="checkbox" name="newsletter" class="notaEsquerda">
  <label class="notaEsquerda">Alterar como administrador</label>
</div>
<div class="divider">.</div>
<div class="inpsenha">
  <input type="password" name="senhaadmin" placeholder="Digite senha do adm...">
  </div>

  </section>
<section class="divider">...</section>
<section class="divider">...</section>
<section class="divider">...</section>

</div>
</div>
</div>
</form>

</body>
    <script>
    	$('.ui.dropdown')
  .dropdown()
;
    </script>

<?php 
  //enviando imagem selecionada para pasta uploads_imagens
  include('codigos.php');

?>