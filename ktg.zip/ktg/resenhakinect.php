<?php
	
	include("cabecalho.php");

?>


<!DOCTYPE html>
<html>
<head>
	<title>JOGOS</title>
	<meta charset="utf-8">
  	<script type="text/javascript" src="semantic/jquery-3.3.1.min.js"></script>
  	<script type="text/javascript" src="semantic/semantic.min.js"></script>
  	<script type="text/javascript" src="funcoes.js"></script>
  	<link rel="stylesheet" type="text/css" href="semantic/semantic.min.css">
  	<link rel="stylesheet" type="text/css" href="css.css">



</head>
<body>

	<div class="divider">.</div>
			
	<section class="sides2">!</section>

	<section id="total">
		<section id="semantique">

     <center><p class="fontetitulo"><h3 class="ui horizontal divider header" id="corcadastrar">RESENHA: KINECT SPORT RIVALS</h3></p></center>
			
      <div class="divider">.</div>
        
        <p class="fontetexto">Existe um competidor em cada um de nós aguardando ser despertado. O Kinect Sports Rivals traz as competições esportivas para um novo mundo, onde as questões de habilidade e precisão são recompensadas. Teste suas habilidades no futebol, escalada, corrida de jet ski, tiro ao alvo, tênis e boliche. Com Kinect Sports Rivals, é você contra o mundo. Um Mundo de Competição: Escolha os seus poderes, aprimore sua habilidade e aperfeiçoe a sua estratégia para competir em vários esportes, eventos esportivos e torneios on-line.
</p>
  			
  			<section class="video">	
	<div class="zoom">
	
	<iframe width="420" height="230" src="https://www.youtube.com/embed/uZSBpyP6UPw" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
	</div>
	</section>	
</section>
  			<p class="fontetexto">
     Os gráficos se destacam entre os pontos fortes do jogo. Com uma possibilidade avançada de modelagem dos personagem, os jogadores precisam apenas se posicionar na frente do Kinect para que uma versão virtual bastante parecida seja criada pelo game.



</p>
  			<p class="fontetexto">Os interessados podem ainda alterar características básicas para que o avatar fique ainda mais semelhante ao jogador. Este recurso é indispensável para a proposta do game, pois cria uma identificação imediata do jogador com a recém elaborada versão virtual.



</p>
   			<p class="fontetexto">Kinect Sports Rivals é sem dúvidas o melhor título já lançado para o Kinect, porém isso não o torna inquestionável. Embora traga inúmeros recursos de personalização e muitas melhorias quando comparado com o título anterior da série, o game ainda peca em detalhes fundamentais como a jogabilidade. Tente não levar ao pé da letra as promessas do jogo para se divertir.

</p>
        
       <section class="estrelacomentario">
        <h4>Classificação</h4>
       <div class="ui large star rating estrela estrelacomentari"></div>
   		</section>
      <section class="autorresenha">
        <a class="ui label">
         <img class="ui right spaced avatar image" src="imagens/avatar2.png">
       <strong> Autora:</strong> Gabriela Campos
        </a>
      </section>
      <div class="divider">!</div>

	<section > 
         <div class="divider">!</div>
			<center><div class="ui small images">
 				<img src="imagens/kinect1.jpg" class="fotop">
  				<img src="imagens/kinect2.jpg" class="fotop">
  				<img src="imagens/kinect3.jpg" class="fotop">
  				<img src="imagens/kinect1.jpg" class="fotop">
  				<img src="imagens/kinect4.jpg" class="fotop">
          
			</div></center>
		</section>
      <div class="divider">.</div>

   <section class="sides2">!</section>

<center><p class="fontetitulo"><h3 class="ui horizontal divider header">
<i class="comments outline icon"></i>
  COMENTÁRIOS
</h3></p></center>

 <div class="margenzinha"></div>
<section id="total">
      <div class="ui comments">
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar2.png">
    </a>
    <div class="content">
      <a class="author">Cristina Moraes</a>
      <div class="metadata">
        <div class="date">1 dia atrás</div>
      </div>
      <div class="text">
        <p>Jogo muito bom e divertido. Meus filhos gostaram muito!! Além de ter um preço mediano para um xbox.  </p>
      </div>
      <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
        <i class="trash icon"></i><a class="delete" >Excluir comentário</a>
      </div>
    </div>

  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar1.png">
    </a>
    <div class="content">
      <a class="author">Samuel Henrique</a>
      <div class="metadata">
        <div class="date">2 dias atrás</div>
      </div>
      <div class="text">
        Eu adorei!
      </div>
       <div class="actions" class="notaEsquerda">
        <a class="reply">Responder</a>
        <i class="trash icon"></i><a class="delete" >Excluir comentário</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea placeholder="Escreva seu comentário..."></textarea>
    </div>
    <div class="ui primary submit labeled icon button">
      <i class="icon edit"></i> Comentar
    </div>
    
  </form>
</div>



  </section>
  <div class="divider">.</div>
  <div class="divider">.</div>




  <script>
    $('.ui.rating')
   .rating({
      initialRating: 3,
      maxRating: 5
   })
  ;
  </script>
</body>
</html>